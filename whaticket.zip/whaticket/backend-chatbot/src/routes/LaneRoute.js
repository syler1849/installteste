const express = require('express');
const router = express.Router();

const LaneController = require('../controllers/LaneController');

router.get('/list', LaneController.list);
router.post('/create', LaneController.create);
router.get('/get/:id', LaneController.get);
router.post('/update/:id', LaneController.update);
router.post('/delete', LaneController.delete);

module.exports = router;