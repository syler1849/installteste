const Sequelize = require('sequelize');
var sequelize = require('./database');

var nametable = 'lane';

var lane = sequelize.define(nametable, {
    id:{
        type:Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    laneId: Sequelize.TEXT('long'),
    title: Sequelize.TEXT('long'),
    label: Sequelize.TEXT('long'),
    createdAt:{
        type: 'TIMESTAMP',
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        allowNull: false
    },
    updatedAt: {
        type: 'TIMESTAMP',
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        allowNull: false
    }
}) 

module.exports = lane;